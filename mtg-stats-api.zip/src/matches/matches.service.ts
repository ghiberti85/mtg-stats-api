import {
  Injectable,
  NotFoundException,
  InternalServerErrorException,
} from '@nestjs/common';
import { supabase } from '../supabaseClient';
import { CreateMatchDto } from './dto/create-match.dto';
import { UpdateMatchDto } from './dto/update-match.dto';

@Injectable()
export class MatchesService {
  // ✅ Cria uma nova partida e retorna todos os campos exigidos pelo DTO
  async createMatch(createMatchDto: CreateMatchDto): Promise<CreateMatchDto> {
    const {
      data,
      error,
    }: { data: CreateMatchDto | null; error: { message: string } | null } =
      await supabase.from('matches').insert([createMatchDto]).select().single();

    if (error) {
      throw new InternalServerErrorException(
        `Erro ao criar a partida: ${error.message}`,
      );
    }

    if (!data) {
      throw new InternalServerErrorException(
        'Erro ao criar a partida: resposta vazia do banco de dados.',
      );
    }

    return data; // Retorna todos os campos exigidos pelo DTO
  }

  // ✅ Obtém uma partida pelo ID
  async getMatchById(id: string): Promise<CreateMatchDto> {
    const { data, error }: { data: CreateMatchDto | null; error: any } =
      await supabase.from('matches').select('*').eq('id', id).single();

    if (error || !data) {
      throw new NotFoundException(`Partida com ID ${id} não encontrada.`);
    }

    return data;
  }

  // ✅ Lista todas as partidas, opcionalmente filtrando por jogador
  async getMatches(playerId?: string): Promise<CreateMatchDto[]> {
    let query = supabase.from('matches').select('*');

    if (playerId) {
      query = query.eq('player_id', playerId); // Ajuste correto da query
    }

    const {
      data,
      error,
    }: { data: CreateMatchDto[] | null; error: { message: string } | null } =
      await query;

    if (error) {
      throw new InternalServerErrorException(
        `Erro ao buscar partidas: ${error.message}`,
      );
    }

    return data ?? [];
  }

  // ✅ Atualiza uma partida pelo ID e retorna os dados atualizados
  async updateMatch(
    matchId: string,
    updateMatchDto: UpdateMatchDto,
  ): Promise<CreateMatchDto> {
    const { data, error }: { data: CreateMatchDto | null; error: any } =
      await supabase
        .from('matches')
        .update(updateMatchDto)
        .eq('id', matchId)
        .select()
        .single();

    if (error || !data) {
      throw new NotFoundException(`Erro ao atualizar partida ${matchId}.`);
    }

    return data;
  }

  // ✅ Remove uma partida pelo ID e retorna uma mensagem de sucesso
  async deleteMatch(matchId: string): Promise<{ message: string }> {
    const { data, error }: { data: CreateMatchDto | null; error: any } =
      await supabase
        .from('matches')
        .delete()
        .eq('id', matchId)
        .select()
        .single();

    if (error || !data) {
      throw new NotFoundException(`Partida com ID ${matchId} não encontrada.`);
    }

    return { message: 'Partida removida com sucesso.' };
  }
}
