import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  Query,
  Patch,
  Delete,
  UseGuards,
} from '@nestjs/common';
import { SupabaseAuthGuard } from '../auth/supabase-auth.guard';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiExtraModels,
} from '@nestjs/swagger';
import { MatchesService } from './matches.service';
import { CreateMatchDto } from './dto/create-match.dto';
import { UpdateMatchDto } from './dto/update-match.dto';

@ApiTags('matches') // Agrupa os endpoints no Swagger
@ApiBearerAuth() // Adiciona autenticação Bearer para toda a rota
@UseGuards(SupabaseAuthGuard) // Protege todas as rotas por padrão
@ApiExtraModels(CreateMatchDto, UpdateMatchDto)
@Controller('matches')
export class MatchesController {
  constructor(private readonly matchesService: MatchesService) {}

  // ✅ Endpoint para criar uma nova partida
  @Post()
  @ApiOperation({ summary: 'Cria uma nova partida' })
  @ApiResponse({
    status: 201,
    description: 'Partida criada com sucesso',
    type: CreateMatchDto,
  })
  @ApiResponse({ status: 400, description: 'Erro ao criar a partida' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async createMatch(
    @Body() createMatchDto: CreateMatchDto,
  ): Promise<CreateMatchDto> {
    return await this.matchesService.createMatch(createMatchDto);
  }

  // ✅ Endpoint para listar todas as partidas ou filtrar por playerId
  @Get()
  @ApiOperation({ summary: 'Lista todas as partidas registradas' })
  @ApiResponse({
    status: 200,
    description: 'Lista de partidas retornada com sucesso',
    type: [CreateMatchDto],
  })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async getMatches(
    @Query('playerId') playerId?: string,
  ): Promise<CreateMatchDto[]> {
    return await this.matchesService.getMatches(playerId);
  }

  // ✅ Endpoint para obter uma partida específica pelo ID
  @Get(':id')
  @ApiOperation({ summary: 'Obtém uma partida pelo ID' })
  @ApiResponse({
    status: 200,
    description: 'Partida encontrada',
    type: CreateMatchDto,
  })
  @ApiResponse({ status: 404, description: 'Partida não encontrada' })
  async getMatchById(@Param('id') id: string): Promise<CreateMatchDto> {
    return await this.matchesService.getMatchById(id);
  }

  // ✅ Endpoint para atualizar uma partida pelo ID
  @Patch(':id')
  @ApiOperation({ summary: 'Atualiza uma partida existente' })
  @ApiResponse({
    status: 200,
    description: 'Partida atualizada com sucesso',
    type: UpdateMatchDto,
  })
  @ApiResponse({ status: 404, description: 'Partida não encontrada' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async updateMatch(
    @Param('id') id: string,
    @Body() updateMatchDto: UpdateMatchDto,
  ): Promise<UpdateMatchDto> {
    return await this.matchesService.updateMatch(id, updateMatchDto);
  }

  // ✅ Endpoint para excluir uma partida pelo ID
  @Delete(':id')
  @ApiOperation({ summary: 'Remove uma partida' })
  @ApiResponse({ status: 200, description: 'Partida removida com sucesso' })
  @ApiResponse({ status: 404, description: 'Partida não encontrada' })
  @ApiResponse({ status: 401, description: 'Não autorizado' })
  async deleteMatch(@Param('id') id: string): Promise<{ message: string }> {
    return await this.matchesService.deleteMatch(id);
  }
}
