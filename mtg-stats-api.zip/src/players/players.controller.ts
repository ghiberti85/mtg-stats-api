// src/players/players.controller.ts
import {
  Controller,
  Post,
  Get,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { SupabaseAuthGuard } from '../auth/supabase-auth.guard';
import { PlayersService } from './players.service';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiExtraModels,
} from '@nestjs/swagger';
import { CreatePlayerDto } from './dto/create-player.dto';
import { UpdatePlayerDto } from './dto/update-player.dto';

@ApiTags('Players')
@ApiBearerAuth() // Requer autenticação Bearer
@UseGuards(SupabaseAuthGuard)
@ApiExtraModels(CreatePlayerDto, UpdatePlayerDto)
@Controller('players')
export class PlayersController {
  constructor(private readonly playersService: PlayersService) {}

  @Post()
  @ApiOperation({ summary: 'Criar um novo jogador' })
  @ApiResponse({ status: 201, description: 'Jogador criado com sucesso' })
  async createPlayer(@Body() createPlayerDto: CreatePlayerDto): Promise<any> {
    return await this.playersService.createPlayer(createPlayerDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os jogadores' })
  @ApiResponse({ status: 200, description: 'Lista de jogadores retornada' })
  async getAllPlayers() {
    return await this.playersService.getPlayers();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar um jogador por ID' })
  @ApiResponse({ status: 200, description: 'Jogador encontrado' })
  @ApiResponse({ status: 404, description: 'Jogador não encontrado' })
  async getPlayerById(@Param('id') id: string) {
    return await this.playersService.getPlayerById(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar um jogador' })
  @ApiResponse({ status: 200, description: 'Jogador atualizado' })
  @ApiResponse({ status: 404, description: 'Jogador não encontrado' })
  async updatePlayer(
    @Param('id') id: string,
    @Body() updatePlayerDto: UpdatePlayerDto,
  ) {
    return await this.playersService.updatePlayer(id, updatePlayerDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover um jogador' })
  @ApiResponse({ status: 200, description: 'Jogador removido com sucesso' })
  @ApiResponse({ status: 404, description: 'Jogador não encontrado' })
  async deletePlayer(@Param('id') id: string) {
    return await this.playersService.deletePlayer(id);
  }
}
