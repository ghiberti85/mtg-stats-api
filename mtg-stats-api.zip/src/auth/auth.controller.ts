import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBody,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { SupabaseAuthGuard } from '../auth/supabase-auth.guard';
import { supabase } from '../supabaseClient';
import { SignInDto } from './dto/signin.dto';
import { SignUpDto } from './dto/signup.dto';

@ApiTags('auth')
@ApiBearerAuth()
@Controller('auth')
export class AuthController {
  @UseGuards(SupabaseAuthGuard)
  @Post('signup')
  @ApiOperation({ summary: 'Registrar um novo usuário' })
  @ApiResponse({ status: 201, description: 'Usuário registrado com sucesso' })
  @ApiResponse({ status: 400, description: 'Erro ao criar usuário' })
  async signUp(@Body() body: SignUpDto) {
    const { data, error } = await supabase.auth.signUp(body);
    if (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
    if (!data?.user) {
      throw new HttpException(
        'No user returned from Supabase',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
    return { user: data.user, session: data.session };
  }

  @Post('signin')
  @ApiOperation({ summary: 'Realiza o login de um usuário' })
  @ApiResponse({ status: 200, description: 'Usuário autenticado com sucesso' })
  @ApiResponse({ status: 400, description: 'Credenciais inválidas' })
  @ApiResponse({ status: 500, description: 'Erro interno no servidor' })
  @ApiBody({ type: SignInDto })
  async signIn(@Body() body: { email: string; password: string }) {
    const { data, error } = await supabase.auth.signInWithPassword(body);
    if (error) {
      throw new HttpException(error.message, HttpStatus.BAD_REQUEST);
    }
    if (!data?.user) {
      throw new HttpException(
        'No user returned from Supabase',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
    return { user: data.user, session: data.session };
  }
  å;
}
