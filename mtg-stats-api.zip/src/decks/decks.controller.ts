// src/decks/decks.controller.ts
import {
  Controller,
  Post,
  Get,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { SupabaseAuthGuard } from '../auth/supabase-auth.guard';
import { DecksService } from './decks.service';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiBearerAuth,
  ApiExtraModels,
} from '@nestjs/swagger';
import { CreateDeckDto } from './dto/create-deck.dto';
import { UpdateDeckDto } from './dto/update-deck.dto';

@ApiTags('Decks')
@ApiBearerAuth() // Requer autenticação Bearer
@UseGuards(SupabaseAuthGuard)
@ApiExtraModels(CreateDeckDto, UpdateDeckDto)
@Controller('decks')
export class DecksController {
  constructor(private readonly decksService: DecksService) {}

  @Post()
  @ApiOperation({ summary: 'Criar um novo deck' })
  @ApiResponse({ status: 201, description: 'Deck criado com sucesso' })
  async createDeck(@Body() createDeckDto: CreateDeckDto) {
    return await this.decksService.createDeck(createDeckDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os decks' })
  @ApiResponse({ status: 200, description: 'Lista de decks retornada' })
  async getAllDecks() {
    return await this.decksService.getDecks();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar um deck por ID' })
  @ApiResponse({ status: 200, description: 'Deck encontrado' })
  @ApiResponse({ status: 404, description: 'Deck não encontrado' })
  async getDeckById(@Param('id') id: string) {
    return await this.decksService.getDeckById(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Atualizar um deck' })
  @ApiResponse({ status: 200, description: 'Deck atualizado' })
  @ApiResponse({ status: 404, description: 'Deck não encontrado' })
  async updateDeck(
    @Param('id') id: string,
    @Body() updateDeckDto: UpdateDeckDto,
  ) {
    return await this.decksService.updateDeck(id, updateDeckDto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Remover um deck' })
  @ApiResponse({ status: 200, description: 'Deck removido com sucesso' })
  @ApiResponse({ status: 404, description: 'Deck não encontrado' })
  async deleteDeck(@Param('id') id: string) {
    return await this.decksService.deleteDeck(id);
  }
}
