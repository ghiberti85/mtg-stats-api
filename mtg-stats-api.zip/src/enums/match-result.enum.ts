// src/enums/match-result.enum.ts
export enum MatchResult {
  WIN = 'win',
  LOSS = 'loss',
}
